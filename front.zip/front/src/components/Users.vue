<template>
  <v-container>
    <v-row class="text-center">
      <div
        class="transition-swing text-h1 mt-1 font-weight-regular"
      >
      Users
      </div>
      <v-col cols="12">
        <v-select
          v-model="filter.gender"
          :items="genders"
          label="Gender"
          @change="getData"
        ></v-select>
        <v-text-field
          v-model="filter.nat"
          label="Country"
          @change="getData"
        />
      </v-col>
    </v-row>
    <v-data-table
      :headers="headers"
      :items="users"
      :items-per-page="10"
      class="elevation-1"
      item-key="login.username"
    >
      <template v-slot:item.options="{ item }">
        <v-icon
          large
          color="primary"
          @click="show(item)"
        >
          mdi-eye
        </v-icon>
    </template>
    </v-data-table>
    <show-user
      :show="showDialog"
      :user="selectedUser"
      @close="close"
    />
  </v-container>
</template>

<script>
import ShowUser from './ShowUser'
import moment from 'moment'

  export default {
    name: 'Users',

    components: {ShowUser},

    data: () => ({
      showDialog: false,
      selectedUser: {},
      genders: [{
          value: null,
          text: 'Select an option'
        },{
          value: 'male',
          text: 'male'
        },{
          value: 'female',
          text: 'female'
      }],
      filter: {
        gender: null,
        age: null,
        nat: null
      },
      headers: [
        { text: 'Gender', sortable: false, value: 'gender' },
        { text: 'Name', sortable: false, value: 'name.first' },
        { text: 'Email', sortable: false, value: 'email' },
        { text: 'Country', sortable: false, value: 'nat' },
        { text: 'Birth date', sortable: false, value: 'dob.date' },
        { text: 'Registry date', sortable: false, value: 'registered.date' },
        { text: 'Options', sortable: false, value: 'options' },
      ],
      users: []
    }),

    computed: {
      url() {
        let url = ''
        url += this.filter.gender ? `&gender=${this.filter.gender}` : ''
        url += this.filter.nat ? `&nat=${this.filter.nat}` : ''
        return url
      }
    },

    created () {
      this.getData();
    },

    methods: {
      getData () {
        this.$http.get(`https://randomuser.me/api/?results=100${this.url}`)
          .then(response => {
            this.users = response.data.results.map(item => {
              item.registered.date = moment(item.registered.date).format('DD/MM/YYYY')
              item.dob.date = moment(item.dob.date).format('DD/MM/YYYY')
              return item;
            });
          })
      },

      show(item) {
        this.showDialog = true
        this.selectedUser = item
      },

      close() {
        this.showDialog = false
        this.selectedUser = {}
      }
    }
  }
</script>
