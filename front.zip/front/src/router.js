import VueRouter from 'vue-router'
import Home from '@/components/Home'
import Users from '@/components/Users'

let routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/users',
    name: 'Users',
    component: Users
  },
];

export default new VueRouter({routes});